#!/usr/bin/env python3
"""Build the bundled offline SQLite database from the supplied names.csv.

Usage: python3 data/build_database.py data/names.csv app/src/main/assets/names.db
Only Python's standard library is required.
"""
import csv
import sqlite3
import sys
from pathlib import Path


def main(source: Path, destination: Path) -> None:
    if not source.is_file():
        raise SystemExit(f"CSV not found: {source}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        destination.unlink()
    connection = sqlite3.connect(destination)
    try:
        connection.executescript("""
            PRAGMA journal_mode = OFF;
            PRAGMA synchronous = OFF;
            PRAGMA temp_store = MEMORY;
            CREATE TABLE raw(name TEXT NOT NULL, year INTEGER NOT NULL,
                             cnt INTEGER NOT NULL, sex TEXT NOT NULL);
            CREATE TABLE year_total(year INTEGER PRIMARY KEY, total INTEGER NOT NULL);
        """)
        totals = {}
        batch = []
        count = 0
        with source.open(encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            if reader.fieldnames != ["name", "year", "num", "total", "sex"]:
                raise ValueError(f"Unexpected CSV header: {reader.fieldnames}")
            for row in reader:
                # The source has padded names, a few embedded newlines, repeated
                # spaces and four mixed-case entries. Match the app's search.
                name = " ".join(row["name"].split()).upper()
                year, number, total = (int(row[column]) for column in ("year", "num", "total"))
                sex = row["sex"].strip()
                if not name or number <= 0 or total <= 0 or sex not in ("", "М", "Ж"):
                    raise ValueError(f"Invalid record: {row}")
                if year in totals and totals[year] != total:
                    raise ValueError(f"Conflicting totals in year {year}")
                totals[year] = total
                batch.append((name, year, number, sex))
                count += 1
                if len(batch) >= 10000:
                    connection.executemany("INSERT INTO raw VALUES(?,?,?,?)", batch)
                    batch.clear()
            if batch:
                connection.executemany("INSERT INTO raw VALUES(?,?,?,?)", batch)
        if not totals or set(totals) != set(range(min(totals), max(totals) + 1)):
            raise ValueError("The data contain missing years")
        connection.executemany("INSERT INTO year_total VALUES(?,?)", sorted(totals.items()))
        for year, expected in totals.items():
            actual = connection.execute("SELECT SUM(cnt) FROM raw WHERE year=?", (year,)).fetchone()[0]
            if actual != expected:
                raise ValueError(f"Year {year}: total={expected}, sum of names={actual}")
        connection.executescript("""
            CREATE TABLE name_year(
                name TEXT NOT NULL, year INTEGER NOT NULL,
                cnt INTEGER NOT NULL, rank INTEGER NOT NULL,
                PRIMARY KEY(name, year)
            ) WITHOUT ROWID;
            INSERT INTO name_year(name,year,cnt,rank)
            SELECT name,year,cnt,RANK() OVER(PARTITION BY year ORDER BY cnt DESC)
            FROM (SELECT name,year,SUM(cnt) cnt FROM raw GROUP BY name,year);

            CREATE TABLE top_year(
                year INTEGER NOT NULL, sex TEXT NOT NULL, position INTEGER NOT NULL,
                name TEXT NOT NULL, cnt INTEGER NOT NULL,
                PRIMARY KEY(year, sex, position)
            ) WITHOUT ROWID;
            INSERT INTO top_year
            SELECT year,sex,position,name,cnt FROM (
                SELECT year,sex,name,cnt,
                       ROW_NUMBER() OVER(PARTITION BY year,sex ORDER BY cnt DESC,name ASC) position
                FROM (SELECT year,sex,name,SUM(cnt) cnt FROM raw
                      WHERE sex IN ('М','Ж') GROUP BY year,sex,name)
            ) WHERE position <= 10;

            CREATE TABLE top_decade(
                decade INTEGER NOT NULL, sex TEXT NOT NULL, position INTEGER NOT NULL,
                name TEXT NOT NULL, cnt INTEGER NOT NULL,
                PRIMARY KEY(decade, sex, position)
            ) WITHOUT ROWID;
            INSERT INTO top_decade
            SELECT decade,sex,position,name,cnt FROM (
                SELECT decade,sex,name,cnt,
                       ROW_NUMBER() OVER(PARTITION BY decade,sex ORDER BY cnt DESC,name ASC) position
                FROM (SELECT CAST(year / 10 AS INTEGER) * 10 decade,sex,name,SUM(cnt) cnt
                      FROM raw WHERE sex IN ('М','Ж') GROUP BY decade,sex,name)
            ) WHERE position <= 10;
            DROP TABLE raw;
        """)
        connection.commit()
        connection.execute("VACUUM")
        print(f"{count} CSV rows; {min(totals)}–{max(totals)}; {destination.stat().st_size:,} bytes")
    finally:
        connection.close()


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: build_database.py names.csv names.db")
    main(Path(sys.argv[1]), Path(sys.argv[2]))
