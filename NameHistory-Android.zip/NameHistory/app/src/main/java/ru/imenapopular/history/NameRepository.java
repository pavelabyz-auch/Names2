package ru.imenapopular.history;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** All percentages use the CSV's total for each year, including rows with unspecified sex. */
final class NameRepository {
    static final class Point {
        final int year;
        final int count;
        final int total;
        final int rank;
        Point(int year, int count, int total, int rank) {
            this.year = year; this.count = count; this.total = total; this.rank = rank;
        }
        double percent() { return total == 0 ? 0 : 100.0 * count / total; }
    }

    static final class Stats {
        final String name;
        final List<Point> points;
        final Point peak;
        final int periodStart;
        final int periodEnd;
        final double periodPercent;
        Stats(String name, List<Point> points, Point peak, int start, int end, double percent) {
            this.name = name; this.points = points; this.peak = peak;
            this.periodStart = start; this.periodEnd = end; this.periodPercent = percent;
        }
    }

    static final class TopItem {
        final int position;
        final String name;
        final int count;
        final double percent;
        TopItem(int position, String name, int count, double percent) {
            this.position = position; this.name = name; this.count = count; this.percent = percent;
        }
    }

    final int firstYear;
    final int lastYear;
    private final int[] yearTotals;
    private final SQLiteDatabase db;

    NameRepository(Context context) throws Exception {
        File file = new File(context.getFilesDir(), "names-v1.db");
        if (!file.exists()) {
            File temporary = new File(context.getFilesDir(), "names-v1.db.tmp");
            try (InputStream in = context.getAssets().open("names.db");
                 FileOutputStream out = new FileOutputStream(temporary)) {
                byte[] bytes = new byte[65536];
                int length;
                while ((length = in.read(bytes)) != -1) out.write(bytes, 0, length);
            }
            if (!temporary.renameTo(file)) throw new IllegalStateException("Не удалось подготовить базу имён");
        }
        db = SQLiteDatabase.openDatabase(file.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
        int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE;
        try (Cursor cursor = db.rawQuery("SELECT MIN(year), MAX(year) FROM year_total", null)) {
            if (!cursor.moveToFirst() || cursor.isNull(0)) throw new IllegalStateException("База имён пуста");
            min = cursor.getInt(0); max = cursor.getInt(1);
        }
        firstYear = min; lastYear = max;
        yearTotals = new int[lastYear - firstYear + 1];
        try (Cursor cursor = db.rawQuery("SELECT year,total FROM year_total", null)) {
            while (cursor.moveToNext()) yearTotals[cursor.getInt(0) - firstYear] = cursor.getInt(1);
        }
    }

    static String normalize(String name) { return name.trim().replaceAll("\\s+", " ").toUpperCase(Locale.ROOT); }

    Stats find(String input) {
        String name = normalize(input);
        if (name.isEmpty()) return null;
        int[] counts = new int[yearTotals.length];
        int[] ranks = new int[yearTotals.length];
        boolean found = false;
        try (Cursor cursor = db.rawQuery(
                "SELECT year,cnt,rank FROM name_year WHERE name=? ORDER BY year", new String[]{name})) {
            while (cursor.moveToNext()) {
                int index = cursor.getInt(0) - firstYear;
                counts[index] = cursor.getInt(1);
                ranks[index] = cursor.getInt(2);
                found = true;
            }
        }
        if (!found) return null;
        List<Point> points = new ArrayList<>(counts.length);
        Point peak = null;
        for (int index = 0; index < counts.length; index++) {
            Point point = new Point(firstYear + index, counts[index], yearTotals[index], ranks[index]);
            points.add(point);
            if (point.count > 0 && (peak == null || point.percent() > peak.percent())) peak = point;
        }
        // Compare the share over every complete rolling 10-year interval.
        long windowCount = 0, windowTotal = 0;
        for (int i = 0; i < Math.min(10, counts.length); i++) {
            windowCount += counts[i]; windowTotal += yearTotals[i];
        }
        int bestStart = 0;
        double bestPercent = 100.0 * windowCount / windowTotal;
        for (int start = 1; start <= counts.length - 10; start++) {
            windowCount += counts[start + 9] - counts[start - 1];
            windowTotal += yearTotals[start + 9] - yearTotals[start - 1];
            double percent = 100.0 * windowCount / windowTotal;
            if (percent > bestPercent) { bestPercent = percent; bestStart = start; }
        }
        return new Stats(name, points, peak, firstYear + bestStart, firstYear + bestStart + 9, bestPercent);
    }

    List<TopItem> top(int selected, boolean decade, String sex) {
        int denominator = 0;
        if (decade) {
            for (int year = Math.max(firstYear, selected); year <= Math.min(lastYear, selected + 9); year++) {
                denominator += yearTotals[year - firstYear];
            }
        } else denominator = yearTotals[selected - firstYear];
        List<TopItem> result = new ArrayList<>(10);
        String table = decade ? "top_decade" : "top_year";
        String column = decade ? "decade" : "year";
        try (Cursor cursor = db.rawQuery("SELECT position,name,cnt FROM " + table
                + " WHERE " + column + "=? AND sex=? ORDER BY position",
                new String[]{Integer.toString(selected), sex})) {
            while (cursor.moveToNext()) {
                int count = cursor.getInt(2);
                result.add(new TopItem(cursor.getInt(0), cursor.getString(1), count,
                        100.0 * count / denominator));
            }
        }
        return result;
    }

    void close() { db.close(); }
}
