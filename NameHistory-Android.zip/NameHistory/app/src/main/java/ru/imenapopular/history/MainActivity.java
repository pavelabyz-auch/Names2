package ru.imenapopular.history;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int INK = Color.rgb(29, 42, 65);
    private static final int MUTED = Color.rgb(103, 115, 132);
    private static final int BACKGROUND = Color.rgb(244, 246, 250);
    private static final int TEAL = HistoryChart.TEAL;
    private static final int CORAL = HistoryChart.CORAL;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile NameRepository repository;
    private LinearLayout body, navigation;
    private int screen = 0, revision = 0;
    private String chosenName = "АННА", firstName = "АННА", secondName = "МАРИЯ";
    private boolean decadeMode = false;
    private int selectedYear = 2000, selectedDecade = 1980;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BACKGROUND);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(20), dp(18), dp(24));
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        navigation = new LinearLayout(this);
        navigation.setBackgroundColor(Color.WHITE);
        navigation.setPadding(dp(6), dp(6), dp(6), dp(6));
        root.addView(navigation, new LinearLayout.LayoutParams(-1, dp(66)));
        setContentView(root);
        heading("Имена по годам", "Подготовка данных…");
        worker.execute(() -> {
            try {
                NameRepository loaded = new NameRepository(getApplicationContext());
                repository = loaded;
                runOnUiThread(() -> { if (!isDestroyed()) showScreen(); });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    body.removeAllViews();
                    heading("Не удалось открыть данные", error.getMessage());
                });
            }
        });
    }

    @Override protected void onDestroy() {
        worker.execute(() -> { if (repository != null) repository.close(); });
        worker.shutdown();
        super.onDestroy();
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        view.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return view;
    }

    private void add(LinearLayout parent, View child, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(bottom);
        parent.addView(child, params);
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(18), dp(18), dp(18), dp(18));
        container.setBackground(background(Color.WHITE, 18));
        add(parent, container, 14);
        return container;
    }

    private void heading(String title, String subtitle) {
        add(body, text(title, 28, INK, true), 5);
        add(body, text(subtitle, 14, MUTED, false), 20);
    }

    private Button button(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(15);
        button.setTextColor(Color.WHITE);
        button.setBackground(background(TEAL, 12));
        return button;
    }

    private EditText input(String hint, String current) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(18);
        input.setTextColor(INK);
        input.setHint(hint);
        input.setText(current);
        input.setSelectAllOnFocus(true);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        return input;
    }

    private void dismissKeyboard(View view) {
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(view.getWindowToken(), 0);
        view.clearFocus();
    }

    private void showScreen() {
        revision++;
        body.removeAllViews();
        navigation.removeAllViews();
        String[] labels = {"Имя", "Топ-10", "Сравнение"};
        for (int i = 0; i < labels.length; i++) {
            final int target = i;
            Button tab = button(labels[i]);
            tab.setTextSize(13);
            tab.setPadding(0, 0, 0, 0);
            tab.setTextColor(screen == i ? Color.WHITE : INK);
            tab.setBackground(background(screen == i ? TEAL : Color.WHITE, 12));
            navigation.addView(tab, new LinearLayout.LayoutParams(0, -1, 1));
            tab.setOnClickListener(v -> { if (screen != target) { screen = target; showScreen(); } });
        }
        if (screen == 0) singleScreen();
        else if (screen == 1) topScreen();
        else comparisonScreen();
    }

    private void singleScreen() {
        heading("Популярность имени", "Данные за " + repository.firstYear + "–" + repository.lastYear + " годы");
        LinearLayout form = card(body);
        add(form, text("Введите имя", 15, MUTED, true), 6);
        EditText name = input("Например, Анна", chosenName);
        add(form, name, 12);
        Button submit = button("Показать историю");
        add(form, submit, 0);
        LinearLayout output = new LinearLayout(this);
        output.setOrientation(LinearLayout.VERTICAL);
        add(body, output, 0);
        submit.setOnClickListener(v -> {
            chosenName = name.getText().toString();
            dismissKeyboard(name);
            loadNames(output, chosenName, null);
        });
        loadNames(output, chosenName, null);
    }

    private void comparisonScreen() {
        heading("Сравнение имён", "Две линии на общей шкале, " + repository.firstYear + "–" + repository.lastYear);
        LinearLayout form = card(body);
        add(form, text("Первое имя", 15, MUTED, true), 4);
        EditText first = input("Например, Анна", firstName);
        add(form, first, 12);
        add(form, text("Второе имя", 15, MUTED, true), 4);
        EditText second = input("Например, Мария", secondName);
        add(form, second, 14);
        Button submit = button("Сравнить");
        add(form, submit, 0);
        LinearLayout output = new LinearLayout(this);
        output.setOrientation(LinearLayout.VERTICAL);
        add(body, output, 0);
        submit.setOnClickListener(v -> {
            firstName = first.getText().toString(); secondName = second.getText().toString();
            dismissKeyboard(second);
            loadNames(output, firstName, secondName);
        });
        loadNames(output, firstName, secondName);
    }

    private void loadNames(LinearLayout output, String first, String second) {
        final int request = ++revision;
        output.removeAllViews();
        add(output, text("Ищем имя…", 15, MUTED, false), 12);
        worker.execute(() -> {
            NameRepository.Stats a = repository.find(first);
            NameRepository.Stats b = second == null ? null : repository.find(second);
            runOnUiThread(() -> {
                if (request != revision || isFinishing() || isDestroyed()) return;
                output.removeAllViews();
                if (a == null || (second != null && b == null)) {
                    LinearLayout message = card(output);
                    add(message, text("Нет данных для имени: "
                            + (a == null ? NameRepository.normalize(first) : NameRepository.normalize(second)),
                            17, INK, true), 6);
                    add(message, text("Проверьте написание. Поиск учитывает полное имя без сокращений.",
                            14, MUTED, false), 0);
                    return;
                }
                if (b == null) {
                    statsCard(output, a, TEAL);
                    chartCard(output, a, null);
                } else {
                    chartCard(output, a, b);
                    statsCard(output, a, TEAL);
                    statsCard(output, b, CORAL);
                }
            });
        });
    }

    private String percentage(double value) {
        return String.format(Locale.getDefault(), value >= 1 ? "%.2f%%"
                : value >= .1 ? "%.3f%%" : value >= .01 ? "%.4f%%" : "%.6f%%", value);
    }

    private void statsCard(LinearLayout output, NameRepository.Stats stats, int accent) {
        LinearLayout panel = card(output);
        add(panel, text(stats.name, 22, accent, true), 14);
        add(panel, text("Пиковый год", 13, MUTED, true), 3);
        add(panel, text(stats.peak.year + "  ·  " + percentage(stats.peak.percent()), 20, INK, true), 4);
        add(panel, text("Место среди всех имён в " + stats.peak.year + " году: " + stats.peak.rank,
                14, MUTED, false), 4);
        add(panel, text(NumberFormat.getIntegerInstance().format(stats.peak.count) + " из "
                + NumberFormat.getIntegerInstance().format(stats.peak.total) + " записей",
                13, MUTED, false), stats.peak.total < 1000 ? 6 : 16);
        if (stats.peak.total < 1000) add(panel,
                text("В этом году выборка мала; процент может резко меняться.", 12, CORAL, false), 16);
        add(panel, text("Лучшие 10 лет подряд", 13, MUTED, true), 3);
        add(panel, text(stats.periodStart + "–" + stats.periodEnd + "  ·  "
                + percentage(stats.periodPercent), 19, INK, true), 0);
    }

    private void chartCard(LinearLayout output, NameRepository.Stats a, NameRepository.Stats b) {
        LinearLayout panel = card(output);
        add(panel, text("Доля имени по годам", 18, INK, true), 4);
        add(panel, text("Годы →  ·  По вертикали — доля от всех записей, %", 12, MUTED, false), 12);
        if (b != null) {
            LinearLayout legend = new LinearLayout(this);
            legend.setOrientation(LinearLayout.HORIZONTAL);
            TextView labelA = text("● " + a.name + "     ", 14, TEAL, true);
            TextView labelB = text("● " + b.name, 14, CORAL, true);
            legend.addView(labelA);
            legend.addView(labelB);
            add(panel, legend, 8);
        }
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(true);
        HistoryChart chart = new HistoryChart(this);
        chart.setSeries(a, b);
        chart.setBackground(background(Color.rgb(250, 251, 253), 10));
        int width = Math.max(dp(760), dp(10) * (repository.lastYear - repository.firstYear));
        scroll.addView(chart, new android.widget.FrameLayout.LayoutParams(width, dp(265)));
        add(panel, scroll, 6);
        add(panel, text("Проведите по графику, чтобы увидеть другие годы", 12, MUTED, false), 0);
    }

    private String decadeLabel(int decade) {
        int start = Math.max(repository.firstYear, decade);
        int end = Math.min(repository.lastYear, decade + 9);
        return start + "–" + end + (end - start < 9 ? " (неполное десятилетие)" : "");
    }

    private Spinner spinner(List<String> options, int index) {
        Spinner result = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, options);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        result.setAdapter(adapter);
        result.setSelection(index);
        return result;
    }

    private void topScreen() {
        heading("Популярные имена", "Топ-10 отдельно для мужчин и женщин");
        LinearLayout controls = card(body);
        LinearLayout switches = new LinearLayout(this);
        switches.setOrientation(LinearLayout.HORIZONTAL);
        Button yearButton = button("По году");
        Button decadeButton = button("По десятилетию");
        yearButton.setTextColor(decadeMode ? INK : Color.WHITE);
        yearButton.setBackground(background(decadeMode ? BACKGROUND : TEAL, 12));
        decadeButton.setTextColor(decadeMode ? Color.WHITE : INK);
        decadeButton.setBackground(background(decadeMode ? TEAL : BACKGROUND, 12));
        switches.addView(yearButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        switches.addView(decadeButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        add(controls, switches, 16);
        yearButton.setOnClickListener(v -> { decadeMode = false; showScreen(); });
        decadeButton.setOnClickListener(v -> { decadeMode = true; showScreen(); });
        add(controls, text(decadeMode ? "Десятилетие" : "Год", 15, MUTED, true), 6);
        List<String> choices = new ArrayList<>();
        final int earliestDecade = repository.firstYear / 10 * 10;
        final int latestDecade = repository.lastYear / 10 * 10;
        if (decadeMode) {
            for (int year = latestDecade; year >= earliestDecade; year -= 10)
                choices.add(decadeLabel(year));
        } else for (int year = repository.lastYear; year >= repository.firstYear; year--)
            choices.add(Integer.toString(year));
        int desired = decadeMode ? (latestDecade - selectedDecade) / 10 : repository.lastYear - selectedYear;
        Spinner period = spinner(choices, Math.max(0, Math.min(choices.size() - 1, desired)));
        add(controls, period, 0);
        LinearLayout output = new LinearLayout(this);
        output.setOrientation(LinearLayout.VERTICAL);
        add(body, output, 0);
        final int pageRevision = revision;
        period.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (pageRevision != revision) return;
                if (decadeMode) selectedDecade = latestDecade - position * 10;
                else selectedYear = repository.lastYear - position;
                showTop(output);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
        showTop(output);
    }

    private void showTop(LinearLayout output) {
        output.removeAllViews();
        int chosen = decadeMode ? selectedDecade : selectedYear;
        if (decadeMode) add(output, text("Период: " + decadeLabel(chosen), 15, MUTED, false), 12);
        topCard(output, "Мужские имена", repository.top(chosen, decadeMode, "М"));
        topCard(output, "Женские имена", repository.top(chosen, decadeMode, "Ж"));
        add(output, text("Процент рассчитан от всех записей за выбранный период. "
                + "Для части редких имён пол в исходных данных не указан.", 12, MUTED, false), 12);
    }

    private void topCard(LinearLayout output, String title, List<NameRepository.TopItem> items) {
        LinearLayout panel = card(output);
        add(panel, text(title, 20, INK, true), 14);
        for (NameRepository.TopItem item : items) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView position = text(String.format(Locale.ROOT, "%02d", item.position), 14, TEAL, true);
            row.addView(position, new LinearLayout.LayoutParams(dp(34), -2));
            TextView name = text(item.name, 15, INK, true);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            row.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
            TextView count = text(percentage(item.percent), 14, MUTED, false);
            count.setContentDescription(NumberFormat.getIntegerInstance().format(item.count)
                    + " записей, " + percentage(item.percent));
            row.addView(count);
            add(panel, row, 13);
        }
    }
}
