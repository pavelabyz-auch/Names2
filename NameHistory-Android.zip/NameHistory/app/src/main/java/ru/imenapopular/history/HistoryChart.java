package ru.imenapopular.history;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Scrollable, year-by-year chart; the vertical axis is the share of all recorded names. */
final class HistoryChart extends View {
    static final int TEAL = Color.rgb(18, 139, 133);
    static final int CORAL = Color.rgb(229, 110, 89);
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<NameRepository.Stats> series = new ArrayList<>();
    private double maxPercent = 1;

    HistoryChart(Context context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }

    void setSeries(NameRepository.Stats first, NameRepository.Stats second) {
        series.clear();
        if (first != null) series.add(first);
        if (second != null) series.add(second);
        double largest = 0;
        for (NameRepository.Stats stats : series)
            for (NameRepository.Point point : stats.points)
                largest = Math.max(largest, point.percent());
        double step = largest > 4 ? 1 : largest > 1 ? .5 : largest > .2 ? .1
                : largest > .04 ? .02 : largest > .004 ? .002 : .0002;
        maxPercent = Math.max(step * 4, Math.ceil(largest * 1.12 / step) * step);
        String description = first == null ? "" : "Популярность «" + first.name + "» по годам в процентах";
        if (second != null) description += " и «" + second.name + "»";
        setContentDescription(description);
        invalidate();
    }

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (series.isEmpty()) return;
        float left = dp(66), right = getWidth() - dp(20);
        float top = dp(22), bottom = getHeight() - dp(44);
        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(android.graphics.Typeface.create("sans-serif", 0));
        paint.setTextSize(dp(11));
        paint.setStrokeWidth(dp(1));
        for (int i = 0; i <= 4; i++) {
            float y = bottom - (bottom - top) * i / 4f;
            paint.setColor(Color.rgb(225, 230, 236));
            canvas.drawLine(left, y, right, y, paint);
            String label = String.format(Locale.getDefault(), maxPercent < .1 ? "%.3f%%"
                    : maxPercent < 1 ? "%.2f%%" : "%.1f%%", maxPercent * i / 4);
            paint.setColor(Color.rgb(103, 115, 132));
            canvas.drawText(label, dp(4), y + dp(4), paint);
        }
        List<NameRepository.Point> points = series.get(0).points;
        int firstYear = points.get(0).year;
        int lastYear = points.get(points.size() - 1).year;
        for (int year = firstYear; year <= lastYear; year++) {
            if (year % 10 != 0 && year != firstYear && year != lastYear) continue;
            float x = left + (right - left) * (year - firstYear) / (lastYear - firstYear);
            paint.setColor(Color.rgb(225, 230, 236));
            canvas.drawLine(x, top, x, bottom, paint);
            paint.setColor(Color.rgb(103, 115, 132));
            canvas.drawText(Integer.toString(year), x - dp(13), bottom + dp(22), paint);
        }
        for (int index = 0; index < series.size(); index++) {
            NameRepository.Stats stats = series.get(index);
            int color = index == 0 ? TEAL : CORAL;
            Path path = new Path();
            for (int i = 0; i < stats.points.size(); i++) {
                NameRepository.Point point = stats.points.get(i);
                float x = left + (right - left) * i / (stats.points.size() - 1);
                float y = bottom - (float) (point.percent() / maxPercent) * (bottom - top);
                if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
            }
            paint.setColor(color);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2.6f));
            paint.setStrokeJoin(Paint.Join.ROUND);
            canvas.drawPath(path, paint);
            paint.setStyle(Paint.Style.FILL);
            float peakX = left + (right - left) * (stats.peak.year - firstYear) / (lastYear - firstYear);
            float peakY = bottom - (float) (stats.peak.percent() / maxPercent) * (bottom - top);
            canvas.drawCircle(peakX, peakY, dp(4.5f), paint);
        }
    }
}
